import { Component, OnInit } from '@angular/core';
import {Project} from '../project';
import {User} from '../user';
import {TaskService} from '../shared_service/task.service';
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.scss']
})
export class AddProjectComponent implements OnInit {
  private project: Project;
  private isCreated:boolean=false;
  private projectExist:boolean=false;
  private projectError:Project;
  private errorMessage:String;
  private projectList: Project[];
  private addOrUpdateBtn: string;
  private closeResult: string;
  private show: boolean=false;
  private startDateSort: string;
  private endDateSort: string;
  private prioritySort: number;
  private completedSort: string;
  private projectSearch:string;
  private userList:User[];
  private dateErrorMsg:any={isError:false,errorMessage:''};
  private addTaskOrUpdate: string;
  private startDate:string;
  private endDate:string;
  public modalref: NgbModalRef;

  constructor(private taskService: TaskService, private modal: NgbModal) {}

  ngOnInit() {
    this.addOrUpdateBtn = "Add";
    this.project = new Project();
    this.project.projectPriority = 0;   
    (<HTMLInputElement> document.getElementById("startDate")).disabled = true;   
    (<HTMLInputElement> document.getElementById("endDate")).disabled = true;   
    this.getUserList();
    this.getProjectList();
  }

  startEndDateChkbox() {
    var startEndDateChkbox = (<HTMLInputElement> document.getElementById("startEndDateChkbox")).checked;
    (<HTMLInputElement> document.getElementById("startDate")).disabled = !startEndDateChkbox;   
    (<HTMLInputElement> document.getElementById("endDate")).disabled = !startEndDateChkbox;  
    if(startEndDateChkbox == true){
      this.startDate = new Date().toISOString().split('T')[0];
      this.project.projectStartDate = this.startDate;
      (<HTMLInputElement> document.getElementById("startDate")).setAttribute('min', this.startDate);
      this.endDate = (new Date(new Date().getTime() + 24 * 60 * 60 * 1000)).toISOString().split('T')[0];
      this.project.projectEndDate = this.endDate;
      (<HTMLInputElement> document.getElementById("endDate")).setAttribute('min', this.endDate);    
    }else{
      this.project.projectStartDate="";
      this.project.projectEndDate="";
    }

  }
  addOrUpdateProject() {
    if(this.addOrUpdateBtn == "Add") {
      this.addUser();
    } else {
      this.updateProject(this.project);
    }     
  }

  addUser(){
    this.taskService.addProject(this.project).subscribe(project=>{
      this.isCreated=true;
      this.projectExist=false;
      this.getProjectList();
    },
  error=>{
    this.projectError=error.error;
    this.isCreated=false;
    this.errorMessage=error.error.description;
    if(error.error.code==409){
      this.isCreated=false;
      this.projectExist=true;
    }
  })
  }

  getProjectList() {
    this.taskService.getProjectList().subscribe((res : Project[])=>{
      this.projectList = res;
      this.show=true;
    });
  }

  editProject(project) {
    this.project=project;
    this.addOrUpdateBtn = "Update";
  }

  updateProject(project:Project) {
    this.taskService.updateProject(this.project).subscribe((project)=>{
      this.resetForm();
      this.getProjectList();
    })
  }

  deleteProject(project) {
    this.taskService.deleteUser(project.projectId).subscribe((project)=>{
      this.resetForm();
      this.getProjectList();
    })    
  }

  resetForm(){
    this.project.project='';
    this.project.projectPriority=null;
    this.project.projectStartDate='';
    this.project.projectEndDate='';
    this.project.employeeId=null;
    this.addOrUpdateBtn="Add";
  }

  open(content) {        
   
    this.modalref = this.modal.open(content, { ariaLabelledBy: 'modal-basic-title', size: 'lg' });
    this.modalref.result.then((result) => {
      this.closeResult = `${result}`;
      
      var splitCloseResult = this.closeResult.split("$$", 3);
      if(splitCloseResult[0] == '--user--') {
        this.project.employeeId = +splitCloseResult[1];
        this.project.userId = +splitCloseResult[2];
      }    
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });

  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  'with';
    }
  }

  getUserList() {
    this.taskService.getUserList().subscribe((res : User[])=>{
      this.userList = res;
    });
  }

  startDateSorting(){
    this.projectSearch = "";
    this.startDateSort = "startDateSort";
    this.endDateSort = "";
    this.prioritySort = null;
    this.completedSort = "";
  }

  endDateSorting(){
    this.projectSearch = "";
    this.startDateSort = "";
    this.endDateSort = "endDateSort";
    this.prioritySort = null;
    this.completedSort = "";
  }

  prioritySorting(){
    this.projectSearch = "";
    this.startDateSort = "";
    this.endDateSort = "";
    this.prioritySort = 0;
    this.completedSort = "";
  }

  completedSorting(){
    this.projectSearch = "";
    this.startDateSort = "";
    this.endDateSort = "";
    this.prioritySort = null;
    this.completedSort = "completedSort";
  }
}
