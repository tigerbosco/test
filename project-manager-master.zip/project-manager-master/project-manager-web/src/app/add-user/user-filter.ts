import {Pipe, PipeTransform } from '@angular/core';
import { User } from '../user';
@Pipe({
    name: 'userSearchFilter' 
})
export class userFilter implements PipeTransform {  
    transform(userList: User[], empIdSearch: Number, firstNameSort: string, lastNameSort: string, employeeIdSort: number){
        if (empIdSearch !=null && userList && userList.length){
        return userList.filter(user =>{
            if (empIdSearch && user.employeeId.toString().indexOf(empIdSearch.toString()) === -1){
                return false;
            }
            return true;
        })
        }
              
        if(firstNameSort != "" && firstNameSort=="firstNameSort") {
        return userList.sort((a, b) => a.firstName.localeCompare(b.firstName));
        }

        if(lastNameSort != "" && lastNameSort=="lastNameSort") {
            return userList.sort((a, b) => a.lastName.localeCompare(b.lastName));
        }

        if(employeeIdSort != null) {
            return userList.sort((a, b) => {
                if (a.employeeId > b.employeeId) {
                    return 1;
                }                
                if (a.employeeId < b.employeeId) {
                    return -1;
                }
                return 0;
            });
        }
        
        else{
            return userList;
        }
    }
}
