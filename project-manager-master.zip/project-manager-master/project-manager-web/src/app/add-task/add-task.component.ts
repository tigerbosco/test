import { Component, OnInit } from '@angular/core';
import {Task} from '../task';
import {ParentTask} from '../parent-task';
import {Project} from '../project';
import {User} from '../user';
import {TaskService} from '../shared_service/task.service';
import {NgbModal, ModalDismissReasons,NgbModalRef} from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.scss']
})
export class AddTaskComponent implements OnInit {
  private task:Task;
  private parentTask:ParentTask;
  private taskError:Task;
  private isCreated:boolean=false;
  private taskExist:boolean=false;
  private errorMessage:String;
  private startDate:string;
  private endDate:string;
  private closeResult: string;
  private parentTaskList:ParentTask[];
  private projectList:Project[];
  private userList:User[];
  private dateErrorMsg:any={isError:false,errorMessage:''};
  private addTaskOrUpdate: string;
  public modalref: NgbModalRef;
  

  constructor(private taskService: TaskService, private modalService: NgbModal) { }

  ngOnInit() {
    this.task = new Task();
    this.parentTask = new ParentTask();
    
    this.task.priority = 0;
    this.startDate = new Date().toISOString().split('T')[0];
    this.task.startDate = this.startDate;
    (<HTMLInputElement> document.getElementById("startDate")).setAttribute('min', this.startDate);
    this.endDate = (new Date(new Date().getTime() + 24 * 60 * 60 * 1000)).toISOString().split('T')[0];
    this.task.endDate = this.endDate;
    (<HTMLInputElement> document.getElementById("endDate")).setAttribute('min', this.endDate);    
    this.getParentTaskList();
    this.getProjectList();
    this.getUserList();
    this.addTaskOrUpdate=this.taskService.retrieveDataForUpdateBtn();
    if(this.addTaskOrUpdate == "Update") {
      this.task = this.taskService.retrieveDataForUpdate();
    }else{
      this.addTaskOrUpdate = 'Add Task';
    }
  }

  open(content) {        

    this.modalref = this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', size: 'lg' });
    this.modalref.result.then((result) => {
      this.closeResult = result;
      var splitCloseResult = this.closeResult.split("$$", 3);
      if(splitCloseResult[0] == '--parentTask--') {
        this.task.parentTask = splitCloseResult[1];
        this.task.parentId = +splitCloseResult[2];
      }
      if(splitCloseResult[0] == '--project--') {
        this.task.project = splitCloseResult[1];
        this.task.projectId = +splitCloseResult[2];
      }
      if(splitCloseResult[0] == '--user--') {
        this.task.employeeId = +splitCloseResult[1];
        this.task.userId = +splitCloseResult[2];
      }        
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
    
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  parentTaskChkbox() {
    this.resetForm();
    var parentTaskChkbox = (<HTMLInputElement> document.getElementById("parentTaskChkbox")).checked;
      (<HTMLInputElement> document.getElementById("parentTask")).disabled = parentTaskChkbox;   
      (<HTMLInputElement> document.getElementById("priority")).disabled = parentTaskChkbox;   
      (<HTMLInputElement> document.getElementById("startDate")).disabled = parentTaskChkbox;   
      (<HTMLInputElement> document.getElementById("endDate")).disabled = parentTaskChkbox;
  }
  resetForm(){
    this.task.task='';
    this.task.priority=null;
    this.task.parentTask='';
    this.task.startDate='';
    this.task.endDate='';
    this.task.project='';
    this.task.employeeId=null;
    this.addTaskOrUpdate='Add Task';
  }

  addTask(){
    this.task.status = 'open';
    this.taskService.addTask(this.task).subscribe(task=>{
      this.isCreated=true;
      this.taskExist=false;
    },
  error=>{
    this.taskError=error.error;
    this.isCreated=false;
    this.errorMessage=error.error.description;
    if(error.error.code==409){
      this.isCreated=false;
      this.taskExist=true;
    }
  })
  }

  getParentTaskList() {
    this.taskService.getParentTaskList().subscribe((res : ParentTask[])=>{
      this.parentTaskList = res;
    });
  }

  getProjectList() {
    this.taskService.getProjectList().subscribe((res : Project[])=>{
      this.projectList = res;
    });
  }

  getUserList() {
    this.taskService.getUserList().subscribe((res : User[])=>{
      this.userList = res;
    });
  }

  validateDate() {
    if(new Date(this.task.startDate) > new Date(this.task.endDate)){
      this.dateErrorMsg={isError:true,errorMessage:'End Date can\'t before start date'};
    } else {
      this.dateErrorMsg={isError:false,errorMessage:''};
    }
  }

  updateTask(task:Task) {
    this.task.status = 'open';
    this.taskService.updateTask(this.task).subscribe((task)=>{
    })
  }

  addTaskOrUpdateBtn(){
    if(this.addTaskOrUpdate == "Add Task") {
      this.addTask();
    } else {
      this.updateTask(this.task);
    }  
  }
}
