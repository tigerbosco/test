import {Pipe, PipeTransform } from '@angular/core';
import { Task } from '../task';
@Pipe({
    name: 'taskSortFilter'
})
export class ViewTaskFilter implements PipeTransform {
    transform(tasks: Task[], startDateSort: string, endDateSort: string, prioritySort: Number, completedSort: string){
        if(startDateSort != "" && startDateSort=="startDateSort") {
            return tasks.sort((a, b) => new Date(a.startDate).toDateString().localeCompare(new Date(b.startDate).toDateString()));
        }
        if(endDateSort != "" && endDateSort=="endDateSort") {
            return tasks.sort((a, b) => new Date(a.endDate).toDateString().localeCompare(new Date(b.endDate).toDateString()));
        }
        if(prioritySort != null) {
            return tasks.sort((a, b) =>{
                if (a.priority > b.priority) {
                    return 1;
                }                
                if (a.priority < b.priority) {
                    return -1;
                }
                return 0;
            });
        }
        if(completedSort != null) {
            return tasks.sort((a, b) => a.status.toString().localeCompare(b.status.toString()));
        }
        else{
            return tasks;
        }
    }
}
