import { browser, by, element } from 'protractor';

export class AppPage {
  navigateTo() {
    return browser.get('/');
  }

  getParagraphText() {
    return element(by.css('app-root h1')).getText();
  }

  getViewTaskRouterLink() {
    return element(by.cssContainingText('a','View Task'));
  }

  getAddUserRouterLink() {
    return element(by.cssContainingText('a','Add User'));
  }

  getAddTaskRouterLink() {
    return element(by.cssContainingText('a','Add Task'));
  }
}
