package net.cts.fse.projectmanager.dto;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

public class TaskManagerDTO {

	private Integer taskId;	
	private Integer parentId;
	@NotEmpty (message="Please enter the taskName")
	private String task;
	private String parentTask;
	@NotNull(message="Please enter the startDate")
	private Date startDate;
	@NotNull(message="Please enter the endDate")
	private Date endDate;
	@NotNull(message="Please select the Priority")
	private Integer priority;
	private String status;
	
	private Integer projectId;
	private String project;
	private Date projectStartDate;
	private Date projectEndDate;
	private Integer projectPriority;
	
	private Integer userId;
	private String firstName;
	private String lastName;
	private Integer employeeId;
	
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public Date getProjectStartDate() {
		return projectStartDate;
	}
	public void setProjectStartDate(Date projectStartDate) {
		this.projectStartDate = projectStartDate;
	}
	public Date getProjectEndDate() {
		return projectEndDate;
	}
	public void setProjectEndDate(Date projectEndDate) {
		this.projectEndDate = projectEndDate;
	}
	public Integer getProjectPriority() {
		return projectPriority;
	}
	public void setProjectPriority(Integer projectPriority) {
		this.projectPriority = projectPriority;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	
	public Integer getTaskId() {
		return taskId;
	}
	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public String getParentTask() {
		return parentTask;
	}
	public void setParentTask(String parentTask) {
		this.parentTask = parentTask;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Integer getPriority() {
		return priority;
	}
	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	private DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
	
	public String toString(){		
		return "taskId :"+this.taskId+","+
				"ParentId :"+this.parentId+","+
				"task :"+this.task+","+
				"parentTask :"+this.parentTask+","+
				"startDate :"+dateFormat.format(this.startDate)+","+
				"endDate :"+dateFormat.format(this.endDate)+","+
				"priority :"+this.priority+"\n";
		
	}
	
}
