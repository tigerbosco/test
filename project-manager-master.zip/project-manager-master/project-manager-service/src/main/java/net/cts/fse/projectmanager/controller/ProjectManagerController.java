package net.cts.fse.projectmanager.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import net.cts.fse.projectmanager.domain.*;
import net.cts.fse.projectmanager.dto.ProjectManagerDTO;
import net.cts.fse.projectmanager.dto.TaskManagerDTO;
import net.cts.fse.projectmanager.exception.*;
import net.cts.fse.projectmanager.service.ProjectManagerServiceImpl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600, allowedHeaders="*")
@RestController
@RequestMapping({"/manage"})
public class ProjectManagerController {
	
	private static final Logger log = LoggerFactory.getLogger(ProjectManagerController.class);
    @Autowired
    private ProjectManagerServiceImpl projectManageService;
    
    private String status = null;
    
    private Map<String,String> validationList;
        
    /**
     * This method is to create the task
     * @param projectManageDTO
     * @return
     * @throws ParseException
     */
    @PostMapping({"/task"})
    public ResponseEntity<Object> createTask(@RequestBody @Validated(ProjectManagerDTO.ValidationOne.class) ProjectManagerDTO projectManageDTO, BindingResult bindingResult) throws RuntimeException, UserException{
    	
    	log.info("Inside create Task method {}", projectManageDTO);
    	
    	if(bindingResult != null && bindingResult.hasErrors()) {
    		validationList = new HashMap<String,String>();
    		for(FieldError fieldError: bindingResult.getFieldErrors()) {
    			validationList.put(fieldError.getField(), fieldError.getDefaultMessage());
    		}
    		return new ResponseEntity<Object>(validationList,HttpStatus.NOT_ACCEPTABLE);
    	}
    	
    	//Create task and parent task entity object
    	Task task = new Task();
    	ParentTask parentTask = new ParentTask();
    	Project project = new Project();
    	User user = new User();
    	
    	//setting the dto object to the the task and parent task bean
    	task.setTaskName(projectManageDTO.getTask());
    	
    	task.setParentTask(parentTask);
    	task.getParentTask().setParentaskName(projectManageDTO.getParentTask());
    	task.getParentTask().setParentId(projectManageDTO.getParentId());
    	
    	project.setProjectId(projectManageDTO.getProjectId());
    	task.setProject(project);
    	
    	user.setUser_Id(projectManageDTO.getUserId());
    	task.setUser(user);
    	    	
    	//Get the sql date from the util date object
    	java.sql.Date sqlStartDate = new java.sql.Date(projectManageDTO.getStartDate().getTime());
    	java.sql.Date sqlEndDate = new java.sql.Date(projectManageDTO.getEndDate().getTime());
    	task.setStartDate(sqlStartDate);
    	task.setEndDate(sqlEndDate);
    	task.setPriority(projectManageDTO.getPriority());
    	task.setStatus(projectManageDTO.getStatus());
    	if(projectManageDTO.getParentId()==null) {
    		ParentTask newParent=new ParentTask();
    		newParent.setParentaskName("No Parent");
    		newParent.setParentId(0);
    	   	projectManageService.addParentTask(parentTask);
    	}
    	Task matchingTask = projectManageService.getMatchingTask(task);
    	
    	if (matchingTask != null) {    		
    		UserException ue = new UserException();
    		ue.setCode(HttpStatus.CONFLICT.value());
    		ue.setMessage("Task with same taskname, startDate, EndDate, priority is already existed");
    		throw ue;
    	}

    	//Call the add task method
    	status = projectManageService.addTask(task);
    	if ("Task Added".equals(status)) {
    		log.info("Task is created successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Object>(projectManageDTO,HttpStatus.OK);
    }
    
    /**
     * This method is to derive the list of task
     * @return projectManageDTOList
     */
    @GetMapping(path ={"/project/{projectId}"})
    public List<ProjectManagerDTO> getTaskList(int projectId){    	
    	//Create projectManagerdto list object
    	log.info("Inside getTaskList method");
    	
    	Project project = new Project();
    	project.setProjectId(projectId);
    	
    	List<ProjectManagerDTO> projectManageDTOList = new ArrayList<ProjectManagerDTO>(); 
    	Project matchingProject = projectManageService.getMatchingProject(project);
    	
    	if(!matchingProject.getTask().isEmpty() && matchingProject.getTask()!=null){
    		for (Task task: matchingProject.getTask()){
        		ProjectManagerDTO projectManageDTO = new ProjectManagerDTO();
        		projectManageDTO.setTaskId(task.getTaskId());
        		projectManageDTO.setTask(task.getTaskName());
        		projectManageDTO.setPriority(task.getPriority());    		    		
        		projectManageDTO.setStartDate(task.getStartDate());
        		projectManageDTO.setEndDate(task.getEndDate());
        		projectManageDTO.setStatus(task.getStatus());
        		if(task.getParentTask() != null) {
        			projectManageDTO.setParentId(task.getParentTask().getParentId());
        			projectManageDTO.setParentTask(task.getParentTask().getParentaskName());
        		}
        		if(task.getProject() != null) {
        			projectManageDTO.setProjectId(task.getProject().getProjectId());
        			projectManageDTO.setProject(task.getProject().getProject());
        			projectManageDTO.setProjectStartDate(task.getProject().getStartDate());
        			projectManageDTO.setProjectEndDate(task.getProject().getEndDate());
        			projectManageDTO.setProjectPriority(task.getProject().getPriority());
        		}
        		if(task.getUser() != null) {
        			projectManageDTO.setUserId(task.getUser().getUser_Id());
        			projectManageDTO.setEmployeeId(task.getUser().getEmployee_Id());
        			projectManageDTO.setFirstName(task.getUser().getFirstName());
        			projectManageDTO.setLastName(task.getUser().getLastName());
        		}
        		projectManageDTOList.add(projectManageDTO);
        	}
    	}    	
    	log.info("List of task retrieved: \n {}", projectManageDTOList);
		return projectManageDTOList;        
    }
    
    @PutMapping({"/task"})
    public ResponseEntity<ProjectManagerDTO> updateTask(@RequestBody ProjectManagerDTO projectManageDTO) throws ParseException{
    	
    	log.info("Inside update Task method {}", projectManageDTO);
    	
    	//Create task and parent task entity object
    	Task task = new Task();
    	ParentTask parentTask = new ParentTask();
    	Project project = new Project();
    	User user = new User();
    	
    	//setting the dto object to the the task and parent task bean
    	task.setTaskName(projectManageDTO.getTask());
    	task.setTaskId(projectManageDTO.getTaskId());
    	task.setParentTask(parentTask);
    	task.getParentTask().setParentaskName(projectManageDTO.getParentTask());
    	task.getParentTask().setParentId(projectManageDTO.getParentId());
    	
    	project.setProjectId(projectManageDTO.getProjectId());
    	task.setProject(project);
    	
    	user.setUser_Id(projectManageDTO.getUserId());
    	task.setUser(user);
    	    	
    	//Get the sql date from the util date object
    	java.sql.Date sqlStartDate = new java.sql.Date(projectManageDTO.getStartDate().getTime());
    	java.sql.Date sqlEndDate = new java.sql.Date(projectManageDTO.getEndDate().getTime());
    	task.setStartDate(sqlStartDate);
    	task.setEndDate(sqlEndDate);
    	task.setPriority(projectManageDTO.getPriority());
    	task.setStatus(projectManageDTO.getStatus());
    	
    	status = projectManageService.updateTask(task);
    	if ("Task Updated".equals(status)) {
    		log.info("Task is updated successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<ProjectManagerDTO>(projectManageDTO,HttpStatus.OK);
    }
    
    @DeleteMapping(path ={"/task/{taskId}"})
    public ResponseEntity<Integer> deleteTask(int taskId) {
    	log.info("Inside delete Task method {}", taskId);
    	Task task = new Task();    	
    	task.setTaskId(taskId);
    	
    	status = projectManageService.deleteTask(task);
    	if ("Task Deleted".equals(status)) {
    		log.info("Task is deleted successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Integer>(taskId,HttpStatus.OK);
    }
    
    /**
     * This method is to create the Parent task
     * @param projectManageDTO
     * @return
     * @throws ParseException
     */
    @PostMapping({"/parentTask"})
    public ResponseEntity<Object> createParentTask(@RequestBody ProjectManagerDTO projectManageDTO, BindingResult bindingResult) throws RuntimeException, UserException{
    	
    	log.info("Inside create Parent Task method {}", projectManageDTO);
    	
    	//Create parent task entity object
    	ParentTask parentTask = new ParentTask();
    	parentTask.setParentaskName(projectManageDTO.getParentTask());
    	
    	//Call the add Parent task method
    	status = projectManageService.addParentTask(parentTask);
    	if ("Parent Task Added".equals(status)) {
    		log.info("Parent Task is created successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Object>(projectManageDTO,HttpStatus.OK);
    }
    
    /**
     * This method is to derive the list of task
     * @return projectManageDTOList
     */
    @GetMapping({"/parentTask"})
    public List<ProjectManagerDTO> getParentTaskList(){    	
    	//Create projectManagerdto list object
    	log.info("Inside getParentTaskList method");
    	List<ProjectManagerDTO> projectManageDTOList = new ArrayList<ProjectManagerDTO>();    	
    	List<ParentTask> listOfParentTask = projectManageService.getParentTaskList();
    	for (ParentTask parentTask: listOfParentTask){
    		ProjectManagerDTO projectManageDTO = new ProjectManagerDTO();
    		projectManageDTO.setParentId(parentTask.getParentId());
    		projectManageDTO.setParentTask(parentTask.getParentaskName());
    		
    		projectManageDTOList.add(projectManageDTO);
    	}
    	log.info("List of parent task retrieved: \n {}", projectManageDTOList);
		return projectManageDTOList;        
    }
    
    @PostMapping({"/project"})
    public ResponseEntity<Object> createProject(@RequestBody ProjectManagerDTO projectManageDTO, BindingResult bindingResult) throws RuntimeException, UserException{
    	
    	log.info("Inside create project method {}", projectManageDTO);
    	
    	Project project = new Project();
    	project.setProject(projectManageDTO.getProject());
    	project.setStartDate(new java.sql.Date(projectManageDTO.getProjectStartDate().getTime()));
    	project.setEndDate(new java.sql.Date(projectManageDTO.getProjectEndDate().getTime()));
    	project.setPriority(projectManageDTO.getProjectPriority());
    	
    	User user = new User();
    	user.setUser_Id(projectManageDTO.getUserId());
    	project.setUser(user);
    	
    	Project matchingProject = projectManageService.getMatchingProject(project);
    	
    	if (matchingProject != null) {    		
    		UserException ue = new UserException();
    		ue.setCode(HttpStatus.CONFLICT.value());
    		ue.setMessage("Project is already existed");
    		throw ue;
    	}

    	//Call the add task method
    	status = projectManageService.addProject(project);
    	if ("Project Added".equals(status)) {
    		log.info("Project is created successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Object>(projectManageDTO,HttpStatus.OK);
    }
    
    /**
     * This method is to derive the list of task
     * @return projectManageDTOList
     */
    @GetMapping({"/project"})
    public List<ProjectManagerDTO> getProjectList(){    	
    	//Create projectManagerdto list object
    	log.info("Inside getProjectList method");
    	List<ProjectManagerDTO> projectManageDTOList = new ArrayList<ProjectManagerDTO>();    	
    	List<Project> listOfProject = projectManageService.getProjectList();
    	for (Project project: listOfProject){
    		ProjectManagerDTO projectManageDTO = new ProjectManagerDTO();
    		projectManageDTO.setProjectId(project.getProjectId());
    		projectManageDTO.setProject(project.getProject());
    		projectManageDTO.setProjectPriority(project.getPriority());    		    		
    		projectManageDTO.setProjectStartDate(project.getStartDate());
    		projectManageDTO.setProjectEndDate(project.getEndDate());
    		if(project.getUser() != null) {
    			projectManageDTO.setEmployeeId(project.getUser().getEmployee_Id());
    			projectManageDTO.setUserId(project.getUser().getUser_Id());
    			projectManageDTO.setFirstName(project.getUser().getFirstName());
    			projectManageDTO.setLastName(project.getUser().getLastName());
    		}
    		
    		Set<TaskManagerDTO> taskManagerList = new HashSet<TaskManagerDTO>();
    		
    		if(!project.getTask().isEmpty() && project.getTask() != null) {
    			int completedTask = 0;
    			for (Task task: project.getTask()) {
    				TaskManagerDTO taskManagerdto = new TaskManagerDTO();
    				taskManagerdto.setTaskId(task.getTaskId());
    				taskManagerdto.setTask(task.getTaskName());
    				taskManagerdto.setPriority(task.getPriority());
    				taskManagerdto.setStartDate(task.getStartDate());
    				taskManagerdto.setEndDate(task.getEndDate());
    				taskManagerdto.setStatus(task.getStatus());
    				if(task.getStatus() == "complete") {
    					completedTask++;
    				}
    				taskManagerList.add(taskManagerdto);
    			}
    			projectManageDTO.setNoOfTaskCompleted(completedTask);
    			projectManageDTO.setNoOfTask(taskManagerList.size());
    			projectManageDTO.setTaskManagerList(taskManagerList);
    		}
    		projectManageDTOList.add(projectManageDTO);
    	}
    	log.info("List of project retrieved: \n {}", projectManageDTOList);
		return projectManageDTOList;        
    }
    
    @PutMapping({"/project"})
    public ResponseEntity<ProjectManagerDTO> updateProject(@RequestBody ProjectManagerDTO projectManageDTO) throws ParseException{
    	
    	log.info("Inside update project method {}", projectManageDTO);
    	Project project = new Project();
    	project.setProject(projectManageDTO.getProject());
    	project.setProjectId(projectManageDTO.getProjectId());
    	project.setStartDate(new java.sql.Date(projectManageDTO.getProjectStartDate().getTime()));
    	project.setEndDate(new java.sql.Date(projectManageDTO.getProjectEndDate().getTime()));
    	project.setPriority(projectManageDTO.getProjectPriority());
    	
    	User user = new User();
    	user.setUser_Id(projectManageDTO.getUserId());
    	project.setUser(user);
    	
    	status = projectManageService.updateProject(project);
    	if ("Project Updated".equals(status)) {
    		log.info("Task is updated successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<ProjectManagerDTO>(projectManageDTO,HttpStatus.OK);
    }
    
    @DeleteMapping(path ={"/project/{projectId}"})
    public ResponseEntity<Integer> deleteProject(int projectId) {
    	log.info("Inside delete Project method {}", projectId);
    	Project project = new Project();    	
    	project.setProjectId(projectId);
    	
    	status = projectManageService.deleteProject(project);
    	if ("Project Deleted".equals(status)) {
    		log.info("Project is deleted successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Integer>(projectId,HttpStatus.OK);
    }
    
    @PostMapping({"/user"})
    public ResponseEntity<Object> createUser(@RequestBody @Validated(ProjectManagerDTO.ValidationTwo.class) ProjectManagerDTO projectManageDTO, BindingResult bindingResult) throws RuntimeException, UserException{
    	
    	log.info("Inside create user method {}", projectManageDTO);
    	
    	if(bindingResult != null && bindingResult.hasErrors()) {
    		validationList = new HashMap<String,String>();
    		for(FieldError fieldError: bindingResult.getFieldErrors()) {
    			validationList.put(fieldError.getField(), fieldError.getDefaultMessage());
    		}
    		return new ResponseEntity<Object>(validationList,HttpStatus.NOT_ACCEPTABLE);
    	}
    	
    	User user = new User();
    	user.setEmployee_Id(projectManageDTO.getEmployeeId());
    	user.setFirstName(projectManageDTO.getFirstName());
    	user.setLastName(projectManageDTO.getLastName());
    	
    	User matchingUser = projectManageService.getMatchingUser(user);
    	
    	if (matchingUser != null) {    		
    		UserException ue = new UserException();
    		ue.setCode(HttpStatus.CONFLICT.value());
    		ue.setMessage("User is already existed");
    		throw ue;
    	}

    	//Call the add task method
    	status = projectManageService.addUser(user);
    	if ("User Added".equals(status)) {
    		log.info("User is created successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Object>(projectManageDTO,HttpStatus.OK);
    }
    
    /**
     * This method is to derive the list of task
     * @return projectManageDTOList
     */
    @GetMapping({"/user"})
    public List<ProjectManagerDTO> getUserList(){    	
    	//Create projectManagerdto list object
    	log.info("Inside getUserList method");
    	List<ProjectManagerDTO> projectManageDTOList = new ArrayList<ProjectManagerDTO>();    	
    	List<User> listOfUser = projectManageService.getUserList();
    	for (User user:listOfUser){
    		ProjectManagerDTO projectManageDTO = new ProjectManagerDTO();
    		projectManageDTO.setUserId(user.getUser_Id());
    		projectManageDTO.setEmployeeId(user.getEmployee_Id());
    		projectManageDTO.setFirstName(user.getFirstName());    		    		
    		projectManageDTO.setLastName(user.getLastName());
    		projectManageDTOList.add(projectManageDTO);
    	}
    	log.info("List of User retrieved: \n {}", projectManageDTOList);
		return projectManageDTOList;        
    }
    
    @PutMapping({"/user"})
    public ResponseEntity<ProjectManagerDTO> updateUser(@RequestBody ProjectManagerDTO projectManageDTO) throws ParseException{
    	
    	log.info("Inside update Task method {}", projectManageDTO);
    	//Create task and parent task entity object
    	
    	User user = new User();
    	user.setEmployee_Id(projectManageDTO.getEmployeeId());
    	user.setFirstName(projectManageDTO.getFirstName());
    	user.setLastName(projectManageDTO.getLastName());
    	user.setUser_Id(projectManageDTO.getUserId());
    	
    	status = projectManageService.updateUser(user);
    	if ("User Updated".equals(status)) {
    		log.info("User is updated successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<ProjectManagerDTO>(projectManageDTO,HttpStatus.OK);
    }
    
    @DeleteMapping(path ={"/user/{userId}"})
    public ResponseEntity<Integer> deleteUser(int userId) {
    	log.info("Inside delete Task method {}", userId);
    	User user = new User();    	
    	user.setUser_Id(userId);
    	
    	status = projectManageService.deleteUser(user);
    	if ("User Deleted".equals(status)) {
    		log.info("User is deleted successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Integer>(userId,HttpStatus.OK);
    }
    
}
