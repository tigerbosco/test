package net.cts.fse.projectmanager.service;

import java.util.List;

import net.cts.fse.projectmanager.domain.Task;


public interface ProjectManagerService {
	String addTask(Task task);
	String updateTask(Task task);
	List<Task> getTaskList();
	String deleteTask(Task task);
	Task getMatchingTask(Task task);
}
