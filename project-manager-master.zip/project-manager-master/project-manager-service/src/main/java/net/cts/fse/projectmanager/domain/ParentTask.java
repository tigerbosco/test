package net.cts.fse.projectmanager.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name = "parenttasktable")
public class ParentTask {
	
	@Id
	@Column(name = "Parent_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer parentId;

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	@Column(name = "Parent_Task")
	private String parentaskName;

	public String getParentaskName() {
		return parentaskName;
	}

	public void setParentaskName(String parentaskName) {
		this.parentaskName = parentaskName;
	}
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "parentTask")
	private Set<Task> task = new HashSet<Task>(0);
	
	public Set<Task> getTask() {
		return task;
	}
	public void setTask(Set<Task> task) {
		this.task = task;
	}

}
