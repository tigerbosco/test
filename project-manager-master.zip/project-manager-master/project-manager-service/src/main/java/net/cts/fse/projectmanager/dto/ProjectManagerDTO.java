package net.cts.fse.projectmanager.dto;

import java.util.Date;
import java.util.Set;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

public class ProjectManagerDTO {
	
	public interface ValidationOne {
        // validation group marker interface
    }

    public interface ValidationTwo {
        // validation group marker interface
    }
    
	private Integer taskId;	
	private Integer parentId;
	@NotEmpty (message="Please enter the taskName", groups = {ValidationOne.class})
	private String task;
	private String parentTask;
	@NotNull(message="Please enter the startDate", groups = {ValidationOne.class})
	private Date startDate;
	@NotNull(message="Please enter the endDate", groups = {ValidationOne.class})
	private Date endDate;
	@NotNull(message="Please select the Priority", groups = {ValidationOne.class})
	private Integer priority;
	private String status;
	
	private Set<TaskManagerDTO> taskManagerList;
	
	private Integer projectId;
	private String project;
	private Date projectStartDate;
	private Date projectEndDate;
	private Integer projectPriority;
	private Integer noOfTask;
	private Integer noOfTaskCompleted;
	
	private Integer userId;
	@NotEmpty (message="Please enter the firstName", groups = {ValidationTwo.class})
	private String firstName;
	@NotEmpty (message="Please enter the lastName", groups = {ValidationTwo.class})
	private String lastName;
	@NotNull(message="Please select the employeeId", groups = {ValidationTwo.class})
	private Integer employeeId;
	
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public Date getProjectStartDate() {
		return projectStartDate;
	}
	public void setProjectStartDate(Date projectStartDate) {
		this.projectStartDate = projectStartDate;
	}
	public Date getProjectEndDate() {
		return projectEndDate;
	}
	public void setProjectEndDate(Date projectEndDate) {
		this.projectEndDate = projectEndDate;
	}
	public Integer getProjectPriority() {
		return projectPriority;
	}
	public void setProjectPriority(Integer projectPriority) {
		this.projectPriority = projectPriority;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	
	public Integer getTaskId() {
		return taskId;
	}
	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public String getParentTask() {
		return parentTask;
	}
	public void setParentTask(String parentTask) {
		this.parentTask = parentTask;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Integer getPriority() {
		return priority;
	}
	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Set<TaskManagerDTO> getTaskManagerList() {
		return taskManagerList;
	}
	public void setTaskManagerList(Set<TaskManagerDTO> taskManagerList) {
		this.taskManagerList = taskManagerList;
	}
	public Integer getNoOfTask() {
		return noOfTask;
	}
	public void setNoOfTask(Integer noOfTask) {
		this.noOfTask = noOfTask;
	}
	public Integer getNoOfTaskCompleted() {
		return noOfTaskCompleted;
	}
	public void setNoOfTaskCompleted(Integer noOfTaskCompleted) {
		this.noOfTaskCompleted = noOfTaskCompleted;
	}
	
}
