package net.cts.fse.projectmanager.security;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
public class ProjectManagerSecurityConfig extends WebSecurityConfigurerAdapter {

	protected void configure(AuthenticationManagerBuilder auth)
			throws Exception {
		auth.inMemoryAuthentication().passwordEncoder(org.springframework.security.crypto.password.NoOpPasswordEncoder.getInstance()).withUser("projMgr").password("projMgr")
				.roles("USER");
	}

	protected void configure(HttpSecurity http) throws Exception {
		
		http.authorizeRequests().antMatchers(HttpMethod.OPTIONS, "/project-manager/**").permitAll();		
		http.httpBasic().and().authorizeRequests().antMatchers(HttpMethod.POST, "/project-manager/**").hasRole("USER")
		.and().authorizeRequests().antMatchers(HttpMethod.PUT, "/project-manager/**").hasRole("USER")
		.and().authorizeRequests().antMatchers(HttpMethod.DELETE, "/project-manager/**").hasRole("USER")
		.and().csrf().disable().headers().frameOptions().disable();
	}

}
