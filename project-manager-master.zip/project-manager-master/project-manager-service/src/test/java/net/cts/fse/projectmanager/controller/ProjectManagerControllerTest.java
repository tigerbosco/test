package net.cts.fse.projectmanager.controller;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;

import net.cts.fse.projectmanager.domain.*;
import net.cts.fse.projectmanager.dto.ProjectManagerDTO;
import net.cts.fse.projectmanager.service.ProjectManagerServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class ProjectManagerControllerTest {
	
	@InjectMocks
	private ProjectManagerController projectMngCtrl;
	@Mock
	private ProjectManagerServiceImpl projectManageService;

	private BindingResult bindingResult;
	private ProjectManagerDTO projectManageDTO;
	private List<ProjectManagerDTO> projectManageDTOList;
	private Task task;
	private ParentTask parentTask;
	private Project project;
	private User user;
	private List<Project> projectList;
	private List<User> userList;
	private List<Task> taskList;
	private Set<Task> taskSet;
	private ResponseEntity<Object> statusObj;
	private ResponseEntity<Integer> statusInt;
	private ResponseEntity<ProjectManagerDTO> status;
	
	@Before
    public void before() {		
		MockitoAnnotations.initMocks(this);		
		projectManageDTO = new ProjectManagerDTO();
		task = new Task();
		project = new Project();
		user = new User();
		projectList = new ArrayList<Project>();
		userList = new ArrayList<User>();
		parentTask = new ParentTask();
		taskList = new ArrayList<Task>();
		taskSet = new HashSet<Task>();
		projectManageDTOList = new ArrayList<ProjectManagerDTO>();
		bindingResult = null;
		status = null;
		statusObj = null;
		statusInt = null;
		createdtoTask();
		createProjectObj();
		createUserObj();
		createTaskObj();
    }
	
	@Test
	public void createTask() throws Exception{			
		Mockito.doReturn("Task Added").when(this.projectManageService).addTask(this.task);
        statusObj = projectMngCtrl.createTask(projectManageDTO, bindingResult);
        assertEquals(200,statusObj.getStatusCode().value());		
	}
	
	@Test
	public void updateTask() throws Exception{
		Mockito.doReturn("Task Updated").when(this.projectManageService).updateTask(this.task);
		status = projectMngCtrl.updateTask(projectManageDTO);
        assertEquals(200,status.getStatusCode().value());		
	}
	
	@Test
	public void deleteTask() throws Exception{
		Mockito.doReturn("Task Deleted").when(this.projectManageService).deleteTask(this.task);
		statusInt = projectMngCtrl.deleteTask(task.getTaskId());
        assertEquals(200,statusInt.getStatusCode().value());		
	}
	
	@Test
	public void getTaskList() throws Exception{
		Mockito.doReturn(project).when(this.projectManageService).getMatchingProject(project);
		projectManageDTOList = projectMngCtrl.getTaskList(10010);
        assertEquals((int)projectManageDTOList.get(0).getTaskId(),taskList.get(0).getTaskId());		
	}
	
	@Test
	public void createProject() throws Exception{			
		Mockito.doReturn("Project Added").when(this.projectManageService).addProject(this.project);
        statusObj = projectMngCtrl.createProject(projectManageDTO, bindingResult);
        assertEquals(200,statusObj.getStatusCode().value());		
	}
	
	@Test
	public void updateProject() throws Exception{
		Mockito.doReturn("Project Updated").when(this.projectManageService).updateProject(this.project);
		status = projectMngCtrl.updateProject(projectManageDTO);
        assertEquals(200,status.getStatusCode().value());		
	}
	
	@Test
	public void deleteProject() throws Exception{
		Mockito.doReturn("Project Deleted").when(this.projectManageService).deleteProject(this.project);
		statusInt = projectMngCtrl.deleteProject(task.getTaskId());
        assertEquals(200,statusInt.getStatusCode().value());		
	}
	
	@Test
	public void getProjectList() throws Exception{
		Mockito.doReturn(projectList).when(this.projectManageService).getProjectList();
		projectManageDTOList = projectMngCtrl.getProjectList();
        assertEquals((int)projectManageDTOList.get(0).getProjectId(),projectList.get(0).getProjectId());		
	}
	
	@Test
	public void createUser() throws Exception{			
		Mockito.doReturn("User Added").when(this.projectManageService).addUser(this.user);
        statusObj = projectMngCtrl.createUser(projectManageDTO, bindingResult);
        assertEquals(200,statusObj.getStatusCode().value());		
	}
	
	@Test
	public void updateUser() throws Exception{
		Mockito.doReturn("User Updated").when(this.projectManageService).updateUser(this.user);
		status = projectMngCtrl.updateUser(projectManageDTO);
        assertEquals(200,status.getStatusCode().value());		
	}
	
	@Test
	public void deleteUser() throws Exception{
		Mockito.doReturn("User Deleted").when(this.projectManageService).deleteUser(this.user);
		statusInt = projectMngCtrl.deleteUser(task.getTaskId());
        assertEquals(200,statusInt.getStatusCode().value());		
	}
	
	@Test
	public void getUserList() throws Exception{
		Mockito.doReturn(userList).when(this.projectManageService).getUserList();
		projectManageDTOList = projectMngCtrl.getUserList();
        assertEquals((int)projectManageDTOList.get(0).getUserId(),userList.get(0).getUser_Id());		
	}
	
	@Test
	public void createParentTask() throws Exception{			
		Mockito.doReturn("Parent Task Added").when(this.projectManageService).addParentTask(this.parentTask);
        statusObj = projectMngCtrl.createParentTask(projectManageDTO, bindingResult);
        assertEquals(200,statusObj.getStatusCode().value());		
	}

	private void createTaskObj() {
		//Create a task object		
		task.setTaskName(projectManageDTO.getTask());
		parentTask.setParentaskName(projectManageDTO.getParentTask());
		task.setParentTask(parentTask);
		task.setPriority(projectManageDTO.getPriority());
		task.setStartDate(new java.sql.Date(projectManageDTO.getStartDate().getTime()));
		task.setEndDate(new java.sql.Date(projectManageDTO.getEndDate().getTime()));
		task.setProject(project);
		task.setUser(user);
		taskList.add(task);
		taskSet.add(task);
	}
	
	private void createProjectObj() {
		//Create a project object		
		project.setProject(projectManageDTO.getProject());
		project.setStartDate(new java.sql.Date(projectManageDTO.getProjectStartDate().getTime()));
		project.setEndDate(new java.sql.Date(projectManageDTO.getProjectEndDate().getTime()));
		project.setPriority(projectManageDTO.getProjectPriority());
		project.setUser(user);
		project.setTask(taskSet);
		projectList.add(project);
	}
	
	private void createUserObj() {
		//Create a user object	
		user.setEmployee_Id(projectManageDTO.getEmployeeId());
		user.setFirstName(projectManageDTO.getFirstName());
		user.setLastName(projectManageDTO.getLastName());
		userList.add(user);
	}

	private void createdtoTask() {
		//Create a dto Task
		projectManageDTO.setTask("Task1");
		projectManageDTO.setParentTask("ParentTaskl");
		projectManageDTO.setPriority(10);
		projectManageDTO.setStartDate(new Date());
		projectManageDTO.setEndDate(new Date());
		
		projectManageDTO.setProject("FSD1");
		projectManageDTO.setProjectStartDate(new Date());
		projectManageDTO.setProjectEndDate(new Date());
		projectManageDTO.setProjectPriority(20);
		
		projectManageDTO.setEmployeeId(10001);
		projectManageDTO.setFirstName("FN");
		projectManageDTO.setLastName("LN");
	}
}
