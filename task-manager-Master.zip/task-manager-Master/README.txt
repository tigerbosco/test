run 'mvn clean install' from "task-manager-all" folder
it should info you that build success
then go to task-manager(microservice) folder and run 'mvn spring-boot:run', it should start the application
check the url: localhost:8080/task-manager/


make sure the my sql is running root@:password and database 'ctsFseTaskMmanager' is created

jdbc:mysql://localhost:3306/ctsFseTaskMmanager