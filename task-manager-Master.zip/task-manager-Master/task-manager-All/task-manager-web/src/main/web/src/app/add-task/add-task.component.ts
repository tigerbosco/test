import { Component, OnInit } from '@angular/core';
import { Task } from '../task';
import { ParentTask } from '../parent-task';

import { TaskService } from '../task_service/task.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
//import { Observable, Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { pipe } from 'rxjs'
import $ from 'jquery';
import { Subject } from "rxjs/Subject";
import "rxjs/add/operator/debounceTime";
import "rxjs/add/operator/distinctUntilChanged";
import { Observable } from "rxjs/Observable";
import "rxjs/add/operator/mergeMap";
import { switchMap, map } from 'rxjs/operators';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/share';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.scss']
})
export class AddTaskComponent implements OnInit {
  public task: Task;
  public parentTask: ParentTask;
  public taskError: Task;
  public isCreated: boolean = false;
  public isMandatory: boolean = false;
  public isAutocomplete: boolean = false;
  public searchTerms = new Subject<string>();
  public parentTasks: Observable<ParentTask[]>;
  public errorMessage: String;
  public startDate: string;
  public endDate: string;
  public closeResult: string;
  public taskList: Task[];
  public parentList: ParentTask[] = [];
  public dateErrorMsg: any = { isError: false, errorMessage: '' };
  public addTaskOrUpdate: string;
  public infoMessage: String;
  constructor(public taskService: TaskService, public modalService: NgbModal) { }

  ngOnInit() {
    //console.log(this.addTaskOrUpdate);    
    this.task = new Task();
    this.parentTask = new ParentTask();

    this.task.priority = 0;
    this.startDate = new Date().toISOString().split('T')[0];
    this.task.startDate = this.startDate;
    (<HTMLInputElement>document.getElementById("startDate")).setAttribute('min', this.startDate);
    this.endDate = (new Date(new Date().getTime() + 24 * 60 * 60 * 1000)).toISOString().split('T')[0];
    this.task.endDate = this.endDate;
    (<HTMLInputElement>document.getElementById("endDate")).setAttribute('min', this.endDate);
    this.getAllParentList();

    this.parentTasks = this.searchTerms
      .debounceTime(300)        // wait for 300ms pause in events  
      .distinctUntilChanged()   // ignore if next search term is same as previous  
      .switchMap(term => term   // switch to new observable each time  
        // return the http search observable  
        ? this.getAllParentList()
        // or the observable of empty heroes if no search term  
        : Observable.of<ParentTask[]>([]))
      .catch(error => {
        // TODO: real error handling  
        console.log(error);
        return Observable.of<ParentTask[]>([]);
      });

  }



  resetForm() {
    this.task.priority = null;
    this.task.parentTask = '';
    this.task.startDate = '';
    this.task.endDate = '';
    this.task.taskName = '';
      this.isMandatory = false;
        this.isCreated = false;
  }

  addTask() {

    this.task.taskId = 0;//for Add

    if (this.validateform()) {
      this.isMandatory = true;
      this.isCreated = false;
      this.errorMessage = ' * Mandatory fields are required.';
      return false;
    } else {
      this.taskService.addTask(this.task).subscribe(task => {
        this.isMandatory = false;
        this.isCreated = true;
        this.infoMessage = 'Task Successfully Created';

      })
    }
  }
  getAllParentList(): Observable<ParentTask[]> {
    return this.taskService.getAllTaskList().map((res: Task[]) => {
      var parents: ParentTask[] = [];

      for (var i = 0; i < res.length; i++) {

        if (res[i].parentId && res[i].parentId != 0) {
          var parent: ParentTask = new ParentTask;
          parent.parentId = res[i].parentId;
          parent.parentTask = res[i].parentTask;
          var exist: Boolean = false;
          for (var k = 0; k < parents.length; k++) {
            if (parents[k] && parents[k].parentId == parent.parentId) {
              exist = true;

            }
          }
          if (!exist) {
            parents.push(parent);
          }
        }
      }
      
      this.parentList = parents;
      return parents;
    }).share();

  }
  validateform() {
    if (this.task.priority == null || this.task.priority == 0 || this.task.taskName == '' || !this.task.taskName || this.task.startDate == '' || this.task.endDate == '') {
      return true;
    }
    return false;
  }
  validateDate() {
    if (new Date(this.task.startDate) > new Date(this.task.endDate)) {
      this.dateErrorMsg = { isError: true, errorMessage: 'End Date can\'t before start date' };
    } else {
      this.dateErrorMsg = { isError: false, errorMessage: '' };
    }
  }
  searchParent(parentTask) {

    if (!parentTask || parentTask.trim() == '') {
      this.isAutocomplete = false;
    } else {
      if (!this.searchTerms.next) {
        this.isAutocomplete = true;
      }
      this.isAutocomplete = true;
      this.searchTerms.next(parentTask);
    }

  }
  onselectParent(ParentTask) {
    if (ParentTask.parentId && ParentTask.parentId != 0) {
      this.task.parentId = ParentTask.parentId;
      this.task.parentTask = ParentTask.parentTask;
      this.isAutocomplete = false;
    }
    else {
      if (this.task.parentTask && this.task.parentTask != '') {
        this.task.parentId = 0;
        this.task.parentTask = ParentTask.parentTask;
      }
      return false;
    }
  }
}
