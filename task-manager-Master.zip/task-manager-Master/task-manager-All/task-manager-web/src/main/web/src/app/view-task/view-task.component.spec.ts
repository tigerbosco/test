import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { ViewTaskComponent } from './view-task.component';

import { Pipe, PipeTransform } from '@angular/core';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { NgbModule, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

describe('ViewTaskComponent', () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(),FormsModule, HttpClientTestingModule],
      declarations: [ ViewTaskComponent],
    })
    .compileComponents();
  }));

  it('should create the view task', () => {
    const fixture = TestBed.createComponent(ViewTaskComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });
});
