import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Task } from '../task';
import { TaskService } from '../task_service/task.service';
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { debounceTime } from 'rxjs/operators';
import { pipe } from 'rxjs'
import $ from 'jquery';
import { Subject } from "rxjs/Subject";
import "rxjs/add/operator/debounceTime";
import "rxjs/add/operator/distinctUntilChanged";

import "rxjs/add/operator/mergeMap";
import { switchMap, map } from 'rxjs/operators';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/share';
import { ParentTask } from '../parent-task';

@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.scss']
})
export class ViewTaskComponent implements OnInit {
  public task: Task;
  public selectedtask: Task;
  public tasks: Task[];
  public show: boolean = false;
  public i: number;
  public closeResult: string;
  public modalref: NgbModalRef;
  public dateErrorMsg: any = { isError: false, errorMessage: '' };
  constructor(public taskService: TaskService, public modalService: NgbModal) { }
  public isUpdated: boolean = false;
  public isMandatory: boolean = false;
  public isAutocomplete: boolean = false;
  public searchTerms = new Subject<string>();
  public parentTasks: Observable<ParentTask[]>;
  public errorMessage: String;
  public startDate: string;
  public endDate: string;
  public taskList: Task[];
  public parentList: ParentTask[] = [];
  public addTaskOrUpdate: string;
  public infoMessage: String;
  public endDateSearch: String;
  public startDateSearch: String;
  public priorityTo: String;
  public priorityFrom: String;
  public taskSearch: String;
  

  public parentSearch: String;
  
  
  
  ngOnInit() {
    this.selectedtask = new Task();
    this.getTaskList();


  }

  addTask() {
   


  }

  getTaskList() {
    this.taskService.getAllTaskList().subscribe((res: Task[]) => {
      this.tasks = res;
      for (var i = 0; i < this.tasks.length; i++) {
        this.tasks[i].startDate = (new Date(this.tasks[i].startDate)).toISOString().split('T')[0];
        this.tasks[i].endDate = (new Date(this.tasks[i].endDate)).toISOString().split('T')[0];
      }
      this.parentTasks = this.searchTerms
        .debounceTime(300)        // wait for 300ms pause in events  
        .distinctUntilChanged()   // ignore if next search term is same as previous  
        .switchMap(term => term   // switch to new observable each time  
          // return the http search observable  
          ? this.getAllParentList()
          // or the observable of empty heroes if no search term  
          : Observable.of<ParentTask[]>([]))
        .catch(error => {
          // TODO: real error handling  
          return Observable.of<ParentTask[]>([]);
        });
    });
  }
  getAllParentList(): Observable<ParentTask[]> {
    return this.taskService.getAllTaskList().map((res: Task[]) => {
      var parents: ParentTask[] = [];

      for (var i = 0; i < res.length; i++) {

        if (res[i].parentId && res[i].parentId != 0) {
          var parent: ParentTask = new ParentTask;
          parent.parentId = res[i].parentId;
          parent.parentTask = res[i].parentTask;
          var exist: Boolean = false;
          for (var k = 0; k < parents.length; k++) {
            if (parents[k] && parents[k].parentId == parent.parentId) {
              exist = true;

            }
          }
          if (!exist) {
            parents.push(parent);
          }
        }
      }

      this.parentList = parents;
      return parents;
    }).share();

  }
  deleteTask(task, i) {
    this.taskService.deleteTask(this.selectedtask.taskId).subscribe((task) => {
      this.getTaskList();
      this.selectedtask = task as Task;
      this.isMandatory = false;
      this.isUpdated = true;
      this.infoMessage = ' Successfully End the Task';
      this.modalref.close('Closing Model Panel');
    })

  }

  open(content, id) {
    this.taskService.getTask(id).subscribe((res: Task) => {

      this.selectedtask = res;
      this.selectedtask.startDate = (new Date(this.selectedtask.startDate)).toISOString().split('T')[0];
      this.selectedtask.endDate = (new Date(this.selectedtask.endDate)).toISOString().split('T')[0];
    });
    this.modalref = this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', size: 'lg' });
    this.modalref.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });

  }
  public getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  updateTask(task: Task) {
    if (this.validateform()) {
      this.isMandatory = true;
      this.isUpdated = false;
      this.errorMessage = ' * Mandatory fields are required.';
      return false;
    } else {

      this.taskService.updateTask(this.selectedtask).subscribe((task) => {
        this.getTaskList();
        this.selectedtask = task as Task;
        this.isMandatory = false;
        this.isUpdated = true;
        this.infoMessage = ' Successfully Updated';
        this.modalref.close('Closing Model Panel');
      })
    }



  }

  enableDisable(task: Task) {
    if (this.task.taskId == task.taskId)
      return true;
    else
      return false;
  }
  validateform() {

    if (this.selectedtask.priority == null || this.selectedtask.priority == 0 || this.selectedtask.taskName == '' || !this.selectedtask.taskName || this.selectedtask.startDate == '' || this.selectedtask.endDate == '') {
      return true;
    }
    return false;
  }
  validateDate() {
    if (new Date(this.selectedtask.startDate) > new Date(this.selectedtask.endDate)) {
      this.dateErrorMsg = { isError: true, errorMessage: 'End Date can\'t before start date' };
    } else {
      this.dateErrorMsg = { isError: false, errorMessage: '' };
    }
  }
  searchParent(parentTask) {
    if (!parentTask || parentTask.trim() == '') {
      this.isAutocomplete = false;
    } else {
      this.selectedtask.parentId = 0;
      if (!this.searchTerms.next) {
        this.isAutocomplete = true;
      }
      this.isAutocomplete = true;
      this.searchTerms.next(parentTask);
    }

  }
  onselectParent(ParentTask) {

    if (ParentTask.parentId && ParentTask.parentId != 0) {
      this.selectedtask.parentId = ParentTask.parentId;
      this.selectedtask.parentTask = ParentTask.parentTask;
      this.isAutocomplete = false;
    }
    else {
      if (this.selectedtask.parentTask && this.selectedtask.parentTask != '') {
        this.selectedtask.parentId = 0;
        this.selectedtask.parentTask = ParentTask.parentTask;
      }
      return false;
    }
  }
}
