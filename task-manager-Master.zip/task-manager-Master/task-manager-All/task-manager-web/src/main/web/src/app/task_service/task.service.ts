import { Injectable } from '@angular/core';
import { Task } from '../task';
import { ParentTask } from '../parent-task';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class TaskService {

  constructor(private httpClient: HttpClient) { }
  private baseUrl = "../task-manager/manage";
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  private tasks: Task[];
  private parentTaskList: ParentTask[];
  private addTaskOrUpdate: string;
  private task: Task;

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      "Authorization": "Basic " + btoa("task-manager-usr:task-manager-pwd")
    })
  };
 
  addTask(task: Task) {
    console.log("call to api");
        return this.httpClient.post(this.baseUrl, JSON.stringify(task), this.httpOptions);
  } 

  getTask(taskId: Number) {
    console.log("In the getTask");
    return this.httpClient.get<Task>(`${this.baseUrl+'/'+taskId}`);
  }

  getAllTaskList() {
    console.log("In the getAllTaskList");
    return this.httpClient.get<ParentTask[]>(this.baseUrl);
  }

  deleteTask(taskId: Number) {
    return this.httpClient.delete(`${this.baseUrl +'/'+taskId}`, this.httpOptions);
  }

  updateTask(task: Task) {
    console.log('update Task');
    console.log(task);
    return this.httpClient.put(this.baseUrl, JSON.stringify(task), this.httpOptions);
  }
}
