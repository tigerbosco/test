import { async, inject, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { AddTaskComponent } from './add-task.component';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { NgbModule, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

describe('AddTaskComponent', () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule.forRoot(),FormsModule, HttpClientTestingModule],
      declarations: [ AddTaskComponent ],
    })
    .compileComponents();
  }));

  it('should create add task', async(() => {
    const fixture = TestBed.createComponent(AddTaskComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
});
