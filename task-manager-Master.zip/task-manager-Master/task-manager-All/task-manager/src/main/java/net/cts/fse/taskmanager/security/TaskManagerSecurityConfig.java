package net.cts.fse.taskmanager.security;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
public class TaskManagerSecurityConfig extends WebSecurityConfigurerAdapter {
	private final String appContext = "/task-manager/**";

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication()
				.passwordEncoder(org.springframework.security.crypto.password.NoOpPasswordEncoder.getInstance())
				.withUser("task-manager-usr").password("task-manager-pwd").roles("USER");
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {

				http.authorizeRequests().antMatchers(HttpMethod.OPTIONS, appContext).permitAll();
		http.httpBasic().and().authorizeRequests().antMatchers(HttpMethod.POST, appContext).hasRole("USER").and()
				.authorizeRequests().antMatchers(HttpMethod.PUT, appContext).hasRole("USER").and()
				.authorizeRequests().antMatchers(HttpMethod.DELETE, appContext).hasRole("USER").and().csrf()
				.disable().headers().frameOptions().disable();
	}

}
