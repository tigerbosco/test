package net.cts.fse.taskmanager.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.cts.fse.taskmanager.domain.Task;
@Repository
public interface TaskManagerRepository extends JpaRepository<Task, Integer>{
	

}
