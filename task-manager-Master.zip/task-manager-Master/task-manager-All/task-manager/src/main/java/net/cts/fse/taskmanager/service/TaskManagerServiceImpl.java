package net.cts.fse.taskmanager.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import net.cts.fse.taskmanager.converter.TaskManagerConverter;
import net.cts.fse.taskmanager.domain.ParentTask;
import net.cts.fse.taskmanager.domain.Task;
import net.cts.fse.taskmanager.dto.TaskManagerDTO;
import net.cts.fse.taskmanager.repository.TaskManagerParentRepository;
import net.cts.fse.taskmanager.repository.TaskManagerRepository;

@Component
public class TaskManagerServiceImpl implements TaskManagerService {
	@Autowired
	TaskManagerRepository repository;

	@Autowired
	TaskManagerParentRepository parentRepository;

	@Override
	public TaskManagerDTO createTask(TaskManagerDTO task) {
		Task taskPojo = TaskManagerConverter.createTaskManager(task);

		if (StringUtils.isEmpty(task.getParentTask())) {

			taskPojo.setParentTask(null);
		} else {
			if(task.getParentId()==null){
				task.setParentId(0);
			}
			ParentTask parent = parentRepository.findOne(task.getParentId());
			if (parent != null) {
				taskPojo.setParentTask(parent);
			} else {
				ParentTask parentPojo = new ParentTask();
				parentPojo.setObjectID(0);
				parentPojo.setParentaskName(task.getParentTask());
				parentPojo.getChildTask().add(taskPojo);
				taskPojo.setParentTask(parentPojo);
			}
		}

		taskPojo = repository.save(taskPojo);

		return TaskManagerConverter.createTaskManagerDto(taskPojo);
	}

	@Override
	public TaskManagerDTO updateTask(TaskManagerDTO task) {
		Task taskPojo = repository.findOne(task.getTaskId());
		taskPojo.setEndDate(task.getEndDate());
		if (task.getParentId() != null && task.getParentId() > 0) {
			ParentTask parentTast = parentRepository.findOne(task.getParentId());

			taskPojo.setParentTask(parentTast);
		} else {
			taskPojo.setParentTask(null);
		}

		taskPojo.setPriority(task.getPriority());
		taskPojo.setStartDate(task.getStartDate());
		taskPojo.setTaskName(task.getTaskName());
		Task newPojo = repository.save(taskPojo);

		return TaskManagerConverter.createTaskManagerDto(newPojo);
	}

	@Override
	public List<TaskManagerDTO> getAllTask() {
		List<Task> pojos = repository.findAll();
		List<TaskManagerDTO> taskDtos = new ArrayList<>();
		for (Task pojo : pojos) {
			TaskManagerDTO taskDto = TaskManagerConverter.createTaskManagerDto(pojo);
			taskDtos.add(taskDto);
		}
		return taskDtos;
	}

	@Override
	public void deleteTask(Integer taskId) {
		repository.delete(taskId);
	}

	@Override
	public TaskManagerDTO getTask(Integer taskId) {
		Task pojo = repository.findOne(taskId);
		return TaskManagerConverter.createTaskManagerDto(pojo);
	}

}
