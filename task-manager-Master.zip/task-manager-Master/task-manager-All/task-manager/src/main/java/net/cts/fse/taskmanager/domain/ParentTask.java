package net.cts.fse.taskmanager.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "PARENT_TASK")
public class ParentTask {

	@Id
	@Column(name = "OBJECT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int objectID;
	
	@OneToMany(mappedBy="parentTask",cascade = CascadeType.ALL)
	private List<Task> childTask =new ArrayList<>();

	@Column(name = "TASK_NAME")
	private String parentaskName;

	public int getObjectID() {
		return objectID;
	}

	public void setObjectID(int objectID) {
		this.objectID = objectID;
	}

	public String getParentaskName() {
		return parentaskName;
	}

	public void setParentaskName(String parentaskName) {
		this.parentaskName = parentaskName;
	}

	public List<Task> getChildTask() {
		return childTask;
	}

	public void setChildTask(List<Task> childTask) {
		this.childTask = childTask;
	}


}
