package net.cts.fse.taskmanager.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PARENT_TASK")
public class ParentTask {

	@Id
	@Column(name = "OBJECT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int objectID;
	
	@OneToOne(mappedBy="parentTask",cascade=CascadeType.ALL)
	private Task childTask;

	@Column(name = "TASK_NAME")
	private String parentaskName;

	public int getObjectID() {
		return objectID;
	}

	public void setObjectID(int objectID) {
		this.objectID = objectID;
	}

	public String getParentaskName() {
		return parentaskName;
	}

	public void setParentaskName(String parentaskName) {
		this.parentaskName = parentaskName;
	}

	

	public Task getChildTask() {
		return childTask;
	}

	public void setChildTask(Task childTask) {
		this.childTask = childTask;
	}

}
