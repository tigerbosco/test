package net.cts.fse.taskmanager.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.cts.fse.taskmanager.domain.ParentTask;
@Repository
public interface TaskManagerParentRepository extends JpaRepository<ParentTask, Integer>{
	

}
