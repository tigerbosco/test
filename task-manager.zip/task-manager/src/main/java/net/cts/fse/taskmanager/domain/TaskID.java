package net.cts.fse.taskmanager.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Embeddable
public class TaskID implements Serializable {

	private static final long serialVersionUID = 3748249336497200950L;
	@Id
	@Column(name = "OBJECT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

}