package net.cts.fse.taskmanager.controller;

import org.springframework.util.StringUtils;

import net.cts.fse.taskmanager.dto.TaskManagerDTO;

public class RequestValidator {
	
	public static void validteCreateOrUpdate(TaskManagerDTO taskManagerDTO){
		if(taskManagerDTO.getTaskId()==null || StringUtils.isEmpty(taskManagerDTO.getTaskName())||taskManagerDTO.getPriority()==null ||taskManagerDTO.getStartDate()==null ||taskManagerDTO.getEndDate()==null ){
			throw new IllegalArgumentException("Not enough information is provided to create or update the task"); 
		}
	}
	
	public static void validteDeleteOrRetreive(Integer id){
		if(id==null || id==0){
			throw new IllegalArgumentException("Not enough information is provided to retreive or delete the task"); 
		}
	}

}
