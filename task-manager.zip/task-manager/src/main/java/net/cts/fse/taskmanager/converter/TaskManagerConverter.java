package net.cts.fse.taskmanager.converter;

import net.cts.fse.taskmanager.domain.ParentTask;
import net.cts.fse.taskmanager.domain.Task;
import net.cts.fse.taskmanager.dto.TaskManagerDTO;

public class TaskManagerConverter {

	public static TaskManagerDTO createTaskManagerDto(Task task) {
		TaskManagerDTO dto = new TaskManagerDTO();
		dto.setEndDate(task.getEndDate());
		if (task.getParentTask() != null) {
			dto.setParentId(task.getParentTask().getObjectID());
			dto.setParentTask(task.getParentTask().getParentaskName());
		}
		dto.setPriority(task.getPriority());
		dto.setStartDate(task.getStartDate());
		dto.setTaskId(task.getId());
		dto.setTaskName(task.getTaskName());
		return dto;
	}

	public static Task createTaskManager(TaskManagerDTO task) {
		Task pojo = new Task();
		pojo.setEndDate(task.getEndDate());
		pojo.setId(task.getTaskId());
		pojo.setParentTask(null);
		pojo.setPriority(task.getPriority());
		pojo.setStartDate(task.getStartDate());
		pojo.setTaskName(task.getTaskName());
		return pojo;
	}

	public static ParentTask createTaskManagerParent(TaskManagerDTO task) {
		ParentTask parentPojo = new ParentTask();
		Task pojo = new Task();
		pojo.setEndDate(task.getEndDate());
		pojo.setId(task.getTaskId());
		pojo.setPriority(task.getPriority());
		pojo.setStartDate(task.getStartDate());
		pojo.setTaskName(task.getTaskName());
		pojo.setParentTask(parentPojo);
		parentPojo.setParentaskName(task.getParentTask());
		parentPojo.setChildTask(pojo);
		parentPojo.setObjectID(task.getParentId());

		return parentPojo;
	}

}
