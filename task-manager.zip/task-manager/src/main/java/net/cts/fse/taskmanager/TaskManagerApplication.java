package net.cts.fse.taskmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author 257540
 *
 */
@SpringBootApplication
public class TaskManagerApplication {
		public static void main(String[] args) {
			SpringApplication.run(TaskManagerApplication.class, args);
		}
}
