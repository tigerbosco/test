package net.cts.fse.taskmanager.service;

import java.util.List;

import net.cts.fse.taskmanager.dto.TaskManagerDTO;

public interface TaskManagerService {
	
	public TaskManagerDTO createTask(TaskManagerDTO task);
	public TaskManagerDTO updateTask(TaskManagerDTO task);
	public List<TaskManagerDTO> getAllTask();
	public TaskManagerDTO getTask(Integer taskId);
	public void deleteTask(Integer taskId);

}
