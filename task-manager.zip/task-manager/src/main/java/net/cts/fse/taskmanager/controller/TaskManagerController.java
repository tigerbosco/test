package net.cts.fse.taskmanager.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.cts.fse.taskmanager.dto.TaskManagerDTO;
import net.cts.fse.taskmanager.service.TaskManagerService;

@RestController
@RequestMapping({ "/manage" })
public class TaskManagerController {
	private static final Logger LOGGER = LoggerFactory.getLogger(TaskManagerController.class);
	@Autowired
	TaskManagerService taskmanagerService;

	@PostMapping
	public ResponseEntity<?> createTask(@RequestBody @Valid TaskManagerDTO taskManageJSON,
			BindingResult bindingResult) {
		LOGGER.info("In Create");
		RequestValidator.validteCreateOrUpdate(taskManageJSON);
		taskManageJSON= taskmanagerService.createTask(taskManageJSON);
		return new ResponseEntity<>(taskManageJSON,HttpStatus.OK);
	}

	@GetMapping(path ={"/{id}"})
	public TaskManagerDTO getTask(@PathVariable(name="id") Integer id) {
		LOGGER.info("In GET by Id");
		RequestValidator.validteDeleteOrRetreive(id);
		return taskmanagerService.getTask(id);
	}
	
	@GetMapping
	public List<TaskManagerDTO> getAllTask() {
		LOGGER.info("In GET All");
		return taskmanagerService.getAllTask();
	}

	@PutMapping
	public ResponseEntity<?> updateTask(@RequestBody @Valid TaskManagerDTO taskManageJSON) {
		LOGGER.info("In Update");
		RequestValidator.validteCreateOrUpdate(taskManageJSON);
		taskManageJSON= taskmanagerService.updateTask(taskManageJSON);
		return new ResponseEntity<>(taskManageJSON,HttpStatus.OK);
	}

	@DeleteMapping(path ={"/{id}"})
	public ResponseEntity<?> deleteTask(@PathVariable(name="id") Integer id) {
		LOGGER.info("In Delete");
		RequestValidator.validteDeleteOrRetreive(id);
		taskmanagerService.deleteTask(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
