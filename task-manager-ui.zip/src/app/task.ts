export class Task {

    taskId: number;
    taskName: string;
    parentId: number;
    parentTask: string;
    priority: number;
    startDate: string;
    endDate: string;
   }
