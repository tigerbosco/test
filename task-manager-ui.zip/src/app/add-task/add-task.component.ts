import { Component, OnInit } from '@angular/core';
import {Task} from '../task';
import {ParentTask} from '../parent-task';
import {Project} from '../project';
import {User} from '../user';
import {TaskService} from '../task_service/task.service';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.scss']
})
export class AddTaskComponent implements OnInit {
  private task:Task;
  private parentTask:ParentTask;
  private taskError:Task;
  private isCreated:boolean=false;
  private taskExist:boolean=false;
  private errorMessage:String;
  private startDate:string;
  private endDate:string;
  private closeResult: string;
  private taskList:Task[];
  private projectList:Project[];
  private userList:User[];
  private dateErrorMsg:any={isError:false,errorMessage:''};
  private addTaskOrUpdate: string;
  private infoMessage:String;
  constructor(private taskService: TaskService, private modalService: NgbModal) { }

  ngOnInit() {
    //console.log(this.addTaskOrUpdate);    
    this.task = new Task();
    this.parentTask = new ParentTask();
    
    this.task.priority = 0;
    this.startDate = new Date().toISOString().split('T')[0];
    this.task.startDate = this.startDate;
    (<HTMLInputElement> document.getElementById("startDate")).setAttribute('min', this.startDate);
    this.endDate = (new Date(new Date().getTime() + 24 * 60 * 60 * 1000)).toISOString().split('T')[0];
    this.task.endDate = this.endDate;
    (<HTMLInputElement> document.getElementById("endDate")).setAttribute('min', this.endDate);    
    this.getAllTaskList();
      
  }

  open(content) {        
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = result;
      console.log(this.closeResult);
      var splitCloseResult = this.closeResult.split("$$", 3);
      if(splitCloseResult[0] == '--parentTask--') {
        this.task.parentTask = splitCloseResult[1];
        this.task.parentId = +splitCloseResult[2];
        console.log(this.task.parentTask);
        console.log(this.task.parentId);
      }           
    }, (reason) => {      
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  parentTaskChkbox() {
    console.log("Inside parentTaskCheckbox");
    this.resetForm();
    var parentTaskChkbox = (<HTMLInputElement> document.getElementById("parentTaskChkbox")).checked;
    console.log(parentTaskChkbox);
    console.log(!parentTaskChkbox);
      (<HTMLInputElement> document.getElementById("parentTask")).disabled = parentTaskChkbox;   
      (<HTMLInputElement> document.getElementById("priority")).disabled = parentTaskChkbox;   
      (<HTMLInputElement> document.getElementById("startDate")).disabled = parentTaskChkbox;   
      (<HTMLInputElement> document.getElementById("endDate")).disabled = parentTaskChkbox;
      //(<HTMLInputElement> document.getElementById("user")).disabled = !parentTaskChkbox;
      //(<HTMLInputElement> document.getElementById("project")).disabled = !parentTaskChkbox;   
  }
  resetForm(){
    this.task.priority=null;
    this.task.parentTask='';
    this.task.startDate='';
    this.task.endDate='';
    this.addTaskOrUpdate='Add Task';
  }

  addTask(){
    console.log(this.task.parentTask);
    console.log(this.task.priority);
    console.log(this.task.startDate);
    console.log(this.task.endDate);
    this.task.taskId=0;//for Add
    this.taskService.addTask(this.task).subscribe(task=>{
      console.log(task);
      this.isCreated=true;
      this.infoMessage='Task Successfully Created';
      this.taskExist=false;
    },
  error=>{
    this.taskError=error.error;
    this.isCreated=false;
    this.errorMessage=error.error.description;
    if(error.error.code==409){
      this.isCreated=false;
      this.taskExist=true;
    }
    console.log(error);
  })
  }

  getAllTaskList() {
    this.taskService.getAllTaskList().subscribe((res : Task[])=>{
      console.log(res);
      this.taskList = res;
      console.log("list of tasks" + this.taskList);
    });
  }

  validateDate() {
    console.log("inside validateDate method");
    console.log(new Date(this.task.startDate));
    console.log(new Date(this.task.endDate));
    if(new Date(this.task.startDate) > new Date(this.task.endDate)){
      console.log("inside 'if' validateDate method");
      this.dateErrorMsg={isError:true,errorMessage:'End Date can\'t before start date'};
    } else {
      this.dateErrorMsg={isError:false,errorMessage:''};
    }
  }

  
}
