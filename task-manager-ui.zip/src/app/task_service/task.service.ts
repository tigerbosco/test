import { Injectable } from '@angular/core';
import { Task } from '../task';
import { ParentTask } from '../parent-task';
import { Project } from '../project';
import { User } from '../user';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class TaskService {

  constructor(private httpClient: HttpClient) { }
  private baseUrl = "../task-manager/manage";
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  private tasks: Task[];
  private parentTaskList: ParentTask[];
  private projectList: Project[];
  private userList: User[];
  private addTaskOrUpdate: string;
  private task: Task;

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      "Authorization": "Basic " + btoa("task-manager-usr:task-manager-pwd")
    })
  };
 
  addTask(task: Task) {
    console.log('task');
    console.log(task);
    return this.httpClient.post(this.baseUrl, JSON.stringify(task), this.httpOptions);
  }

  getTaskList(projectId: Number) {
    console.log("In the getTaskList");
    return this.httpClient.get<Task[]>(`${this.baseUrl + '/project' + '/projectId'}?projectId=${projectId}`);
  }

  getAllTaskList() {
    console.log("In the getAllTaskList");
    return this.httpClient.get<ParentTask[]>(this.baseUrl);
  }

  deleteTask(taskId: Number) {
    return this.httpClient.delete(`${this.baseUrl + 'task/taskId'}?taskId=${taskId}`, this.httpOptions);
  }

  updateTask(task: Task) {
    console.log(task);
    return this.httpClient.put(this.baseUrl + '/task', JSON.stringify(task), this.httpOptions);
  }

  addUser(user: User) {
    console.log(user);
    return this.httpClient.post(this.baseUrl + '/user', JSON.stringify(user), this.httpOptions);
  }

  deleteUser(userId: Number) {
    return this.httpClient.delete(`${this.baseUrl + '/user' + '/userId'}?userId=${userId}`, this.httpOptions);
  }

  updateUser(user: User) {
    console.log(User);
    return this.httpClient.put(this.baseUrl + '/user', JSON.stringify(user), this.httpOptions);
  }

  getUserList() {
    console.log("In the getUserList");
    return this.httpClient.get<User[]>(this.baseUrl + '/user');
  }

  getProjectList() {
    console.log("In the getProjectList");
    return this.httpClient.get<Project[]>(this.baseUrl + '/project');
  }

  addProject(project: Project) {
    console.log(project);
    return this.httpClient.post(this.baseUrl + '/project', JSON.stringify(project), this.httpOptions);
  }

  deleteProject(projectId: Number) {
    return this.httpClient.delete(`${this.baseUrl + '/project' + '/projectId'}?projectId=${projectId}`, this.httpOptions);
  }

  updateProject(project: Project) {
    console.log(project);
    return this.httpClient.put(this.baseUrl + '/project', JSON.stringify(project), this.httpOptions);
  }

  storeDataForUpdate(task: Task, addTaskOrUpdate: string) {
    this.addTaskOrUpdate = addTaskOrUpdate;
    this.task = task;
  }

  retrieveDataForUpdateBtn() {
    return this.addTaskOrUpdate;
  }
  retrieveDataForUpdate() {
    this.addTaskOrUpdate = '';
    return this.task;
  }

}
