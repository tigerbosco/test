import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { TaskService } from './task.service';
import { Task } from '../task';

describe('TaskService', () => {

  let service: TaskService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [TaskService]
    });

    service = TestBed.get(TaskService);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('should be created for addTask', () => {
    const res: string = 'Added';
    expect(service).toBeTruthy();
    service.addTask({ taskId: 1, task: 'TaskTest1', parentId: 1,
      parentTask: 'parentTaskTest1', priority: 30, startDate: '', 
      endDate:''}).subscribe((res) => {
      expect(res).toEqual('Added');
    });

    const req = httpMock.expectOne(`http://localhost:8080/taskmanagerFSD/taskManager`, 'call to api');
    expect(req.request.method).toBe('POST');

    req.flush(res);
    httpMock.verify();
  });

  it('should be created for getTaskList', () => {
    const taskList: Task[] = [
      { taskId: 1, task: 'TaskTest1', parentId: 1,
      parentTask: 'parentTaskTest1', priority: 30, startDate: '12/12/2018', 
      endDate:'12/12/2018'}, 
      { taskId: 2, task: 'TaskTest2', parentId: 2,
      parentTask: 'parentTaskTest2', priority: 10, startDate: '11/11/2018', 
      endDate:'11/11/2018'},
    ];

    service.getTaskList().subscribe(res => {
      expect(res.length).toEqual(2);
      expect(res).toEqual(taskList);
    });

    const req = httpMock.expectOne(`http://localhost:8080/taskmanagerFSD/taskManager`, 'call to api');
    expect(req.request.method).toBe('GET');

    req.flush(taskList);
    httpMock.verify();
  });

  it('should be created for updateTask', () => {
    const res: string = 'Updated';
    expect(service).toBeTruthy();

    service.updateTask({ taskId: 1, task: 'TaskTest1update', parentId: 1,
      parentTask: 'parentTaskTest1update', priority: 30, startDate: '', 
      endDate:''}).subscribe((res) => {
      expect(res).toEqual('Updated');
    });

    const req = httpMock.expectOne(`http://localhost:8080/taskmanagerFSD/taskManager`, 'call to api');
    expect(req.request.method).toBe('PUT');

    req.flush(res);
    httpMock.verify();
  });

  it('should be created for deleteTask', () => {
    const res: string = 'Deleted';
    const taskId: number = 1; 
    expect(service).toBeTruthy();

    service.deleteTask(taskId).subscribe((res) => {
      expect(res).toEqual('Deleted');
    });

    const req = httpMock.expectOne(`http://localhost:8080/taskmanagerFSD/taskManager/taskId?taskId=${taskId}`, 'call to api');
    expect(req.request.method).toBe('DELETE');

    req.flush(res);
    httpMock.verify();
  });
});
