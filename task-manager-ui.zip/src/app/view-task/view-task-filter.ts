import { Pipe, PipeTransform } from '@angular/core';
import { Task } from '../task';
@Pipe({
    name: 'taskSortFilter'
})
export class ViewTaskFilter implements PipeTransform {
    transform(tasks: Task[], startDateSort: string, endDateSort: string, prioritySort: Number, completedSort: string) {
        if (startDateSort != "" && startDateSort == "startDateSort") {
            console.log(startDateSort);
            return tasks.sort((a, b) => new Date(a.startDate).toDateString().localeCompare(new Date(b.startDate).toDateString()));
        }
        if (endDateSort != "" && endDateSort == "endDateSort") {
            console.log(endDateSort);
            return tasks.sort((a, b) => new Date(a.endDate).toDateString().localeCompare(new Date(b.endDate).toDateString()));
        }
        if (prioritySort != null) {
            console.log(prioritySort);
            return tasks.sort((a, b) => {
                console.log(a.priority);
                console.log(b.priority);
                if (a.priority > b.priority) {
                    return 1;
                }
                if (a.priority < b.priority) {
                    return -1;
                }
                return 0;
            });
        }
        return tasks;
    }
}



//if (tasks && tasks.length){
  //  return tasks.filter(task =>{
    //    if (taskSearch && task.task.toLowerCase().indexOf(taskSearch.toLowerCase()) === -1){
      //      return false;
       // }
        //if (parentSearch && task.parentTask.toLowerCase().indexOf(parentSearch.toLowerCase()) === -1){
          //  return false;
        //}
        //if (priorityFrom && task.priority<priorityFrom){
          //  return false;
        //}
        //if (priorityTo && task.priority>priorityTo){
          //  return false;
        //}
        //if (startDateSearch && task.startDate!=startDateSearch){
          //  return false;
        //}
        //if (endDateSearch && task.endDate!=endDateSearch){
          //  return false;
        //}
        //return true;
   //})
//}
