import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Task } from '../task';
import { TaskService } from '../task_service/task.service';
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { debounceTime } from 'rxjs/operators';
import { pipe } from 'rxjs'
import $ from 'jquery';
import { Subject } from "rxjs/Subject";
import "rxjs/add/operator/debounceTime";
import "rxjs/add/operator/distinctUntilChanged";

import "rxjs/add/operator/mergeMap";
import { switchMap, map } from 'rxjs/operators';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/share';
import { ParentTask } from '../parent-task';

@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.scss']
})
export class ViewTaskComponent implements OnInit {
  private task: Task;
  private selectedtask: Task;
  private tasks: Task[];
  private show: boolean = false;
  private i: number;
  private closeResult: string;
  public modalref: NgbModalRef;
  private dateErrorMsg: any = { isError: false, errorMessage: '' };
  constructor(private taskService: TaskService, public modalService: NgbModal) { }
  private isUpdated: boolean = false;
  private isMandatory: boolean = false;
  private isAutocomplete: boolean = false;
  private searchTerms = new Subject<string>();
  public parentTasks: Observable<ParentTask[]>;
  private errorMessage: String;
  private startDate: string;
  private endDate: string;
  private taskList: Task[];
  private parentList: ParentTask[] = [];
  private addTaskOrUpdate: string;
  private infoMessage: String;

  ngOnInit() {
    this.selectedtask = new Task();
    this.getTaskList();


  }

  getTaskList() {
    this.taskService.getAllTaskList().subscribe((res: Task[]) => {
      console.log(res);
      this.tasks = res;
      for (var i = 0; i < this.tasks.length; i++) {
        this.tasks[i].startDate = (new Date(this.tasks[i].startDate)).toISOString().split('T')[0];
        this.tasks[i].endDate = (new Date(this.tasks[i].endDate)).toISOString().split('T')[0];
      }
      console.log("list of tasks" + this.tasks);
      this.parentTasks = this.searchTerms
        .debounceTime(300)        // wait for 300ms pause in events  
        .distinctUntilChanged()   // ignore if next search term is same as previous  
        .switchMap(term => term   // switch to new observable each time  
          // return the http search observable  
          ? this.getAllParentList()
          // or the observable of empty heroes if no search term  
          : Observable.of<ParentTask[]>([]))
        .catch(error => {
          // TODO: real error handling  
          console.log(error);
          return Observable.of<ParentTask[]>([]);
        });
    });
  }
  getAllParentList(): Observable<ParentTask[]> {
    return this.taskService.getAllTaskList().map((res: Task[]) => {
      var parents: ParentTask[] = [];

      for (var i = 0; i < res.length; i++) {

        if (res[i].parentId && res[i].parentId != 0) {
          var parent: ParentTask = new ParentTask;
          parent.parentId = res[i].parentId;
          parent.parentTask = res[i].parentTask;
          var exist: Boolean = false;
          for (var k = 0; k < parents.length; k++) {
            if (parents[k] && parents[k].parentId == parent.parentId) {
              exist = true;

            }
          }
          if (!exist) {
            parents.push(parent);
          }
        }
      }

      this.parentList = parents;
      return parents;
    }).share();

  }
  deleteTask(task, i) {
    this.taskService.deleteTask(this.selectedtask.taskId).subscribe((task) => {
      this.getTaskList();
      this.selectedtask = task as Task;
      console.log(task);
      this.isMandatory = false;
      this.isUpdated = true;
      this.infoMessage = ' Successfully End the Task';
      this.modalref.close('Closing Model Panel');
    })
    
  }

  open(content, id) {
    this.taskService.getTask(id).subscribe((res: Task) => {

      this.selectedtask = res;
      this.selectedtask.startDate = (new Date(this.selectedtask.startDate)).toISOString().split('T')[0];
      this.selectedtask.endDate = (new Date(this.selectedtask.endDate)).toISOString().split('T')[0];
      console.log(this.selectedtask);
    });
    this.modalref = this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', size: 'lg' });
    this.modalref.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });

  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  updateTask(task: Task) {
    if (this.validateform()) {
      this.isMandatory = true;
      this.isUpdated = false;
      this.errorMessage = ' * Mandatory fields are required.';
      return false;
    } else {

      this.taskService.updateTask(this.selectedtask).subscribe((task) => {
        this.getTaskList();
        this.selectedtask = task as Task;
        console.log(task);
        this.isMandatory = false;
        this.isUpdated = true;
        this.infoMessage = ' Successfully Updated';
        this.modalref.close('Closing Model Panel');
      })
    }



  }

  enableDisable(task: Task) {
    if (this.task.taskId == task.taskId)
      return true;
    else
      return false;
  }
  validateform() {
    console.log('in validate');
   
    if (this.selectedtask.priority == null || this.selectedtask.priority == 0 || this.selectedtask.taskName == '' || !this.selectedtask.taskName || this.selectedtask.startDate == '' || this.selectedtask.endDate == '') {
      return true;
    }
    return false;
  }
  validateDate() {
    console.log("inside validateDate method");
    console.log(new Date(this.selectedtask.startDate));
    console.log(new Date(this.selectedtask.endDate));
    if (new Date(this.selectedtask.startDate) > new Date(this.selectedtask.endDate)) {
      console.log("inside 'if' validateDate method");
      this.dateErrorMsg = { isError: true, errorMessage: 'End Date can\'t before start date' };
    } else {
      this.dateErrorMsg = { isError: false, errorMessage: '' };
    }
  }
  searchParent(parentTask) {
    console.log('in searh');
    if (!parentTask || parentTask.trim() == '') {
      this.isAutocomplete = false;
    } else {
      this.selectedtask.parentId = 0;
      if (!this.searchTerms.next) {
        console.log(true);
        this.isAutocomplete = true;
      }
      this.isAutocomplete = true;
      this.searchTerms.next(parentTask);
    }

  }
  onselectParent(ParentTask) {

    if (ParentTask.parentId && ParentTask.parentId != 0) {
      this.selectedtask.parentId = ParentTask.parentId;
      this.selectedtask.parentTask = ParentTask.parentTask;
      this.isAutocomplete = false;
    }
    else {
      if (this.selectedtask.parentTask && this.selectedtask.parentTask != '') {
        this.selectedtask.parentId = 0;
        this.selectedtask.parentTask = ParentTask.parentTask;
      }
      return false;
    }
  }
}
