import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Task } from '../task';
import { TaskService } from '../task_service/task.service';
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.scss']
})
export class ViewTaskComponent implements OnInit {
  private task: Task;
  private selectedtask: Task;
  private tasks: Task[];
  private show: boolean = false;
  private i: number;
  private closeResult: string;
  public modalref: NgbModalRef;
  private dateErrorMsg: any = { isError: false, errorMessage: '' };
  constructor(private taskService: TaskService, public modalService: NgbModal) { }

  ngOnInit() {
    this.selectedtask = new Task();
    this.getTaskList();

  }

  getTaskList() {
    this.taskService.getAllTaskList().subscribe((res: Task[]) => {
      console.log(res);
      this.tasks = res;
      for (var i = 0; i < this.tasks.length; i++) {
        this.tasks[i].startDate = (new Date(this.tasks[i].startDate)).toISOString().split('T')[0];
        this.tasks[i].endDate = (new Date(this.tasks[i].endDate)).toISOString().split('T')[0];
      }
      console.log("list of tasks" + this.tasks);
    });
  }

  deleteTask(task, i) {
    this.taskService.deleteTask(task.taskId).subscribe((task) => {
      console.log(task);
    })
    var editId = 'edit' + i;
    (<HTMLInputElement>document.getElementById(i)).disabled = true;
    (<HTMLInputElement>document.getElementById(editId)).disabled = true;
  }

  open(content, id) {
    this.taskService.getTask(id + 1).subscribe((res: Task) => {

      this.selectedtask = res;
      this.selectedtask.startDate = (new Date(this.selectedtask.startDate)).toISOString().split('T')[0];
        this.selectedtask.endDate = (new Date(this.selectedtask.endDate)).toISOString().split('T')[0];
      console.log(this.selectedtask);
    });
    this.modalref = this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' ,size:'lg'});
    this.modalref.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });

  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  updateTask(task: Task) {
    this.taskService.updateTask(this.task).subscribe((task) => {
      console.log(task);
    })
    this.getTaskList();
  }

  enableDisable(task: Task) {
    if (this.task.taskId == task.taskId)
      return true;
    else
      return false;
  }
}
